﻿// spd_shrage.cpp : Ten plik zawiera funkcję „main”. W nim rozpoczyna się i kończy wykonywanie programu.
//

#include <iostream>
#include <fstream>
using namespace std;
int Shrage(int N, int* R, int* P, int* Q, int* X)
{
    int t = 0, cmax = 0;
    int F[100];
    for (int i = 0; i < N; i++) {
        F[i] = 0;
    }
    for (int n = 0; n < N; n++)
    {
        int k = 0;
        for (int i = 0; i < N; i++)
        {
            if ((R[i] <= t) && (F[i] != 2))
            {
                F[i] = 1;
                k++;
            }
        }
        if (k == 0)
        {
            t = 999999;
            for (int i = 0; i < N; i++)
            {
                if (F[i] == 0)
                {
                    t = min(t, R[i]);
                }
            }
            for (int i = 0; i < N; i++)
            {
                if ((R[i] <= t) && (F[i] != 2))
                {
                    F[i] = 1;
                }
            }

        }
        int maxQ = -1;
        for (int i = 0; i < N; i++)
        {
            if ((F[i] == 1) && (maxQ < Q[i]))
            {
                maxQ = Q[i];
                k = i;
            }
        }
        X[n] = k;
        F[k] = 2;
        t += P[k];
        cmax = max(cmax, t + Q[k]);
    }
    return cmax;
}
int Shrage_z_podzialem(int N, int* R, int* P, int* Q)
{
    int t = 0, cmax = 0;
    int F[100], Pomp[100];
    for (int i = 0; i < N; i++) {
        Pomp[i] = P[i];
    }
    for (int i = 0; i < N; i++) {
        F[i] = 0;
    }
    for (int n = 0; n < 2 * N; n++)
    {
        int k = 0;
        for (int i = 0; i < N; i++)
        {
            if ((R[i] <= t) && (F[i] != 2))
            {
                F[i] = 1;
                k++;
            }
        }
        if (k == 0)
        {
            t = 999999;
            for (int i = 0; i < N; i++)
            {
                if (F[i] == 0)
                {
                    t = min(t, R[i]);
                }
            }
            for (int i = 0; i < N; i++)
            {
                if ((R[i] <= t) && (F[i] != 2))
                {
                    F[i] = 1;
                }
            }

        }
        int maxQ = -1;
        for (int i = 0; i < N; i++)
        {
            if ((F[i] == 1) && (maxQ < Q[i]))
            {
                maxQ = Q[i];
                k = i;
            }
        }

        int RKolejnegoZadania = 99999, p;
        for (int i = 0; i < N; i++)
        {
            if (F[i] == 0)
            {
                RKolejnegoZadania = min(RKolejnegoZadania, R[i]);
            }
        }
        if (Pomp[k] + t <= RKolejnegoZadania) {
            F[k] = 2;
            t += Pomp[k];
            cmax = max(cmax, t + Q[k]);
        }
        else {
            p = RKolejnegoZadania - t;
            Pomp[k] -= p;
            t += p;
        }
    }
    return cmax;
}

void Blok(int N, int* R, int* P, int* Q, int* X, int& cI, int& cR, int& cQ)
{
    int posB = -1, m = 0, cmax = 0;
    int tmp[100];
    for (int i = 0; i < N; i++)
    {
        int j = X[i];
        tmp[i] = (m >= R[j]);
        m = max(m, R[j]) + P[j];
        if (cmax < m + Q[j])
        {
            cmax = m + Q[j];
            posB = i;
        }
    }
    int i = posB, j = -1;
    int bQ = Q[X[posB]];
    int bR = R[X[posB]];
    int bP = P[X[posB]];
    while (tmp[i])
    {
        if (Q[X[--i]] < bQ)
        {
            j = X[i];
            break;
        }
        bR = min(bR, R[X[i]]);
        bP += P[X[i]];
    }
    cI = j;
    cR = bR + bP;
    cQ = bQ + bP;
}
void Carlier(int N, int* R, int* P, int* Q, int* X, int& UB)
{
    if (Shrage_z_podzialem(N, R, P, Q) >= UB)
    {
        return;
    }

    int sCmax = Shrage(N, R, P, Q, X);
    if (sCmax < UB)
    {
        UB = sCmax;
    }

    int j, jr, jq;
    Blok(N, R, P, Q, X, j, jr, jq);
    if (j < 0)
    {
        return;
    }

    int tmpR = R[j];
    int tmpQ = Q[j];
    R[j] = jr;
    Carlier(N, R, P, Q, X, UB);
    R[j] = tmpR;
    Q[j] = jq;
    Carlier(N, R, P, Q, X, UB);
    Q[j] = tmpQ;
}

int main()
{
    int N, R[100], P[100], Q[100], X[100];
    ifstream f("dane.txt");
    string str = "data.", str1, str2;
 
    for (int x = 0; x <= 8; x++)
    {
        char tab_str[4];
        snprintf(tab_str, 4, "%03d", x);
        string kolejnosc(tab_str);
        str1 = str + kolejnosc + ":";

        while (str2 != str1) {
            f >> str2;
        }

        f >> N;
        for (int i = 0; i < N; i++)
        {
            f >> R[i] >> P[i] >> Q[i];
        }

        int UB = Shrage(N, R, P, Q, X);
        Carlier(N, R, P, Q, X, UB);
        cout << str1 << " Carlier " << UB << endl;

        for (int i = 0; i < N; i++)
        {
            cout << X[i] + 1 << " ";
        }
        cout << endl;
    }
    return 0;
}

// Uruchomienie programu: Ctrl + F5 lub menu Debugowanie > Uruchom bez debugowania
// Debugowanie programu: F5 lub menu Debugowanie > Rozpocznij debugowanie

// Porady dotyczące rozpoczynania pracy:
//   1. Użyj okna Eksploratora rozwiązań, aby dodać pliki i zarządzać nimi
//   2. Użyj okna programu Team Explorer, aby nawiązać połączenie z kontrolą źródła
//   3. Użyj okna Dane wyjściowe, aby sprawdzić dane wyjściowe kompilacji i inne komunikaty
//   4. Użyj okna Lista błędów, aby zobaczyć błędy
//   5. Wybierz pozycję Projekt > Dodaj nowy element, aby utworzyć nowe pliki kodu, lub wybierz pozycję Projekt > Dodaj istniejący element, aby dodać istniejące pliku kodu do projektu
//   6. Aby w przyszłości ponownie otworzyć ten projekt, przejdź do pozycji Plik > Otwórz > Projekt i wybierz plik sln
